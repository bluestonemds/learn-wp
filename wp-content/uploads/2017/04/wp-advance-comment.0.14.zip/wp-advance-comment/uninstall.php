<?php

/*
** This function will be called when the plugin will be uninstalled. 
*/

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}